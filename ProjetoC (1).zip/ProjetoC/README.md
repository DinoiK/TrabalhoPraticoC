# Projeto_Prático_C
<p align = "center">Projeto prático da cadeira de Algoritmos e estruturas de Dados com a linguagem C,IPCA(2020)</br><img src ="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fsvgsilh.com%2Fpng-512%2F2025120.png&f=1&nofb=1" height = "200px"></img></p></br>
<h1>Alunos:</br>
19744 - Rubem Fridolino Christ Neto<br>
21094 - Alexandre Pires Carvalho<br>
19427 - João Pedro Guedes Barbosa de Oliveira</h1>
