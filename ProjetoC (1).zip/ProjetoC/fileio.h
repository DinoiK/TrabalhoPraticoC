void fileManipulation();
void saveGame();